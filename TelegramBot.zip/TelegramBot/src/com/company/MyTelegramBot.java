package com.company;

import org.telegram.telegrambots.bots.TelegramLongPollingBot;
import org.telegram.telegrambots.meta.api.methods.send.SendMessage;
import org.telegram.telegrambots.meta.api.methods.updates.DeleteWebhook;
import org.telegram.telegrambots.meta.api.methods.updatingmessages.DeleteMessage;
import org.telegram.telegrambots.meta.api.objects.Message;
import org.telegram.telegrambots.meta.api.objects.Update;
import org.telegram.telegrambots.meta.api.objects.replykeyboard.InlineKeyboardMarkup;
import org.telegram.telegrambots.meta.api.objects.replykeyboard.ReplyKeyboardMarkup;
import org.telegram.telegrambots.meta.api.objects.replykeyboard.buttons.InlineKeyboardButton;
import org.telegram.telegrambots.meta.api.objects.replykeyboard.buttons.KeyboardRow;
import org.telegram.telegrambots.meta.exceptions.TelegramApiException;

import java.io.*;
import java.util.*;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

class MyTelegramBot extends TelegramLongPollingBot {
    private final Map<Long, Long> pairingUsers = Collections.synchronizedMap(new HashMap<>());
    private final List<Long> waitingUsers = Collections.synchronizedList(new ArrayList<>());
    private final File dataFile = new File("meetingChat.txt");

    @Override
    public String getBotUsername() {
        return "@pairetopairebot";
    }

    @Override
    public String getBotToken() {
        return "6446664130:AAETunWhvNZf66LWfTH6sDCIT-WZTWj7xo4";
    }

    @Override
    public void onUpdateReceived(Update update) {
        if (update.hasMessage() && update.getMessage().hasText()) {
            handleIncomingMessage(update);
        } else if (update.hasCallbackQuery()) {
            handleCallbackQuery(update);
        } else if (update.hasMessage()) {
            deleteMessage(update.getMessage().getChatId(), update.getMessage().getMessageId());
            sendMessage(update.getMessage().getChatId(), "Allow message text only!");
        }
    }
    private long msgBot = 0;
    private long partner = 0;
    private void handleIncomingMessage(Update update) {
        saveUserData(update);
        long chatId = update.getMessage().getChatId();
        long messageId = update.getMessage().getMessageId();
        String messageText = update.getMessage().getText();

        switch (messageText) {
            case "/start":
                deleteMessage(chatId, messageId);
                sendPersistentMenu(chatId);
                break;
            case "/Delete":
                deleteMessages(chatId , this.partner);
                break;
            case "/Matching":
                handleStartCommand(chatId);
                break;
            case "/Help":
                sendHelpMenu(chatId);
                break;
            case "/Stop":
                handleStopCommand(chatId);
                break;
            default:
                handleDefaultMessage(chatId, messageText);
                break;
        }

    }

    private void handleDefaultMessage(long chatId, String messageText) {
        if (pairingUsers.containsKey(chatId)) {
            forwardMessage(chatId, messageText);
        } else {
            sendMessageWithDelay(chatId, "Send /Matching to begin matching with a partner.", 5, TimeUnit.SECONDS);
        }
    }

    private void saveUserData(Update update) {
        long userId = update.getMessage().getFrom().getId();
        String firstName = update.getMessage().getFrom().getFirstName();
        String lastName = update.getMessage().getFrom().getLastName();
        String username = update.getMessage().getFrom().getUserName();
        long chatId = update.getMessage().getChatId();
        long messageId = update.getMessage().getMessageId();

        Set<String> existingEntries = new HashSet<>();

        // Read existing entries from the file
        if (dataFile.exists()) {
            try (BufferedReader reader = new BufferedReader(new FileReader(dataFile))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    existingEntries.add(line.trim());
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        // Create the new entry
        String newEntry = String.format("%d,%s,%s,%s,%d,%d,%d,", userId, firstName, lastName, username, chatId, messageId,this.msgBot);

        // Check if the new entry already exists
        if (!existingEntries.contains(newEntry)) {
            // Write the new entry to the file
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(dataFile, true))) {
                writer.write(newEntry);
                writer.newLine();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private void sendPersistentMenu(long chatId) {
        SendMessage message = new SendMessage();
        message.setChatId(String.valueOf(chatId));
        message.setText("Select From The Options Below:");

        ReplyKeyboardMarkup keyboardMarkup = new ReplyKeyboardMarkup();
        keyboardMarkup.setResizeKeyboard(true);
        keyboardMarkup.setOneTimeKeyboard(false);  // Persistent menu

        KeyboardRow row = new KeyboardRow();
        row.add("/Matching");
        row.add("/Help");
        row.add("/Stop");
        row.add("/Delete");

        keyboardMarkup.setKeyboard(Collections.singletonList(row));
        message.setReplyMarkup(keyboardMarkup);

        try {
            execute(message);
        } catch (TelegramApiException e) {
            e.printStackTrace();
        }
    }

    private void sendHelpMenu(long chatId) {
        SendMessage message = new SendMessage();
        message.setChatId(String.valueOf(chatId));
        message.setText("How to use the bot:");

        InlineKeyboardMarkup markupInline = new InlineKeyboardMarkup();
        List<InlineKeyboardButton> rowInline = new ArrayList<>();

        rowInline.add(createInlineButton("Matching", "help_matching"));
        rowInline.add(createInlineButton("Stop", "help_stop"));
        rowInline.add(createInlineButton("Delete", "help_delete"));
        rowInline.add(createInlineButton("Help", "help_help"));

        markupInline.setKeyboard(Collections.singletonList(rowInline));
        message.setReplyMarkup(markupInline);

        try {
            execute(message);
        } catch (TelegramApiException e) {
            e.printStackTrace();
        }
    }

    private InlineKeyboardButton createInlineButton(String text, String callbackData) {
        InlineKeyboardButton button = new InlineKeyboardButton();
        button.setText(text);
        button.setCallbackData(callbackData);
        return button;
    }

    private void handleCallbackQuery(Update update) {
        String callbackData = update.getCallbackQuery().getData();
        long chatId = update.getCallbackQuery().getMessage().getChatId();

        if ("help_matching".equals(callbackData)) {
            sendMessage(chatId, "Use /Matching to begin matching with a partner.");

        } else if ("help_stop".equals(callbackData)) {
            sendMessage(chatId, "Use /Stop to stop the chat with your partner.");

        }else if ("help_delete".equals(callbackData)) {
            sendMessage(chatId, "Use /Delete to Delete All messages.");

        }else {
            sendMessage(chatId, "Use /Help to show you this Menu");

        }
    }

    public void setupBot() {
        try {
            // Remove the existing webhook
            DeleteWebhook deleteWebhookRequest = new DeleteWebhook();
            execute(deleteWebhookRequest);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void handleStartCommand(long chatId) {
        synchronized (waitingUsers) {
            if (!pairingUsers.containsKey(chatId)) {
                if (waitingUsers.isEmpty()) {
                    waitingUsers.add(chatId);
                    sendMessage(chatId, "Waiting for a partner...");
                } else {
                    long partnerChatId = waitingUsers.remove(0);
                    if (partnerChatId != chatId) {
                        pairUsers(chatId, partnerChatId);
                    } else {
                        waitingUsers.add(chatId);  // Add back if accidentally matched with self
                        sendMessage(chatId, "You can't connect with yourself. Please wait for someone else.");
                    }
                }
            } else {
                sendMessage(chatId, "You are already paired with a partner.");
            }
        }
    }

    private void pairUsers(long chatId, long partnerChatId) {
        pairingUsers.put(chatId, partnerChatId);
        pairingUsers.put(partnerChatId, chatId);

        sendMessage(chatId, "Paired with a partner! Start chatting.");
        sendMessage(partnerChatId, "Paired with a partner! Start chatting.");
    }

    private void handleStopCommand(long chatId) {
        synchronized (pairingUsers) {
            if (pairingUsers.containsKey(chatId)) {
                long partnerChatId = pairingUsers.remove(chatId);
                pairingUsers.remove(partnerChatId);

                sendMessage(chatId, "You have been disconnected from your partner.");
                sendMessage(partnerChatId, "Your partner has disconnected.");
            } else {
                sendMessage(chatId, "You are not paired with any partner.");
                waitingUsers.remove(chatId);
            }
        }
    }

    private void forwardMessage(long chatId, String message) {
        Long partnerChatId = pairingUsers.get(chatId);
        partner = partnerChatId;
        if (partnerChatId != null) {
            sendMessage(partnerChatId, message);
        }
    }

    private void sendMessageWithDelay(long chatId, String text, long delay, TimeUnit unit) {
        ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);
        scheduler.schedule(() -> sendMessage(chatId, text), delay, unit);
    }

    private void sendMessage(long chatId, String message) {
        SendMessage sendMessage = new SendMessage();
        sendMessage.setChatId(String.valueOf(chatId));
        sendMessage.setText(message);

        try {
            Message messageBot = execute(sendMessage);
             msgBot = messageBot.getMessageId();

        } catch (TelegramApiException e) {
            System.err.println("Message not sent: " + e.getMessage());

        }
    }

    private void deleteMessages(long chatId , long partnerId) {
        try {
            Scanner scanner = new Scanner(new File("meetingChat.txt"));
            List<String> dataFile = new ArrayList<>();
            List<String> data = new ArrayList<>();
            String msgId = "";
            int index = 0;

            while (scanner.hasNextLine()) {
                dataFile.add(scanner.nextLine());
            }
            scanner.close();

            for (String line : dataFile) {
                for (int a = 0; a < line.length(); a++) {
                    String alpha = line.substring(a, a + 1);

                    if (alpha.equals(",")) {
                        index++;

                        switch (index) {
                            case 6, 7 -> {
                                data.add(msgId);
                                msgId = "";
                                if (index == 7){
                                    index = 0;
                                }
                            }
                            default -> msgId = "";
                        }

                    } else {
                        msgId = msgId.concat(alpha);
                    }
                }
            }

            for (String msgid : data) {
                deleteMessage(chatId, Long.parseLong(msgid));
                deleteMessage(partnerId, Long.parseLong(msgid));
                System.out.println("message deleted : " + msgid + " | " + partnerId);
            }
            FileWriter emptyFile = new FileWriter("C:\\Users\\zakaria\\IdeaProjects\\TelegramBot\\meetingChat.txt");
            emptyFile.write("");


        } catch (IOException e) {
            e.printStackTrace();

        }
    }

    private void deleteMessage(long chatId, long messageId) {
        DeleteMessage deleteMessage = new DeleteMessage();
        deleteMessage.setChatId(String.valueOf(chatId));
        deleteMessage.setMessageId((int) messageId);

        try {
            execute(deleteMessage);
        } catch (TelegramApiException e) {

            if (!e.toString().isEmpty()){ return; }
        }
    }
}
